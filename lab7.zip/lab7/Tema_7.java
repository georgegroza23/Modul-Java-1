package modul1.lab7;

public class Tema_7 {
	public static void main(String[] args) {
		System.out.println("CERINTA:");
		CerintaExercitiiTema_7.arataCerintaExercitiului(3);
		System.out.println("---------------------------- \n");
		System.out.println("REZOLVARE:");
		RezolvareaExercitiilorTema_7.arataRezolvareaExercitiului(3);
	}
}